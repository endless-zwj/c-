﻿#ifndef __GAME_WINDOW_SET_KEYBOARD_H__
#define __GAME_WINDOW_SET_KEYBOARD_H__

void GameWindow_InitSetKeyboardWindow(void);

void GameWindow_ShowSetKeyboardWindow(void);

void GameWindow_HideSetKeyboardWindow(void);

void GameWindow_DestroySetKeyboardWindow(void);
#endif
