#ifndef __GAME_WINDOW_ABOUT_H__
#define __GAME_WINDOW_ABOUT_H__

void GameWindow_InitAboutWindow(void);

void GameWindow_ShowAboutWindow(void);

void GameWindow_HideAboutWindow(void);

void GameWindow_DestroyAboutWindow(void);

#endif
