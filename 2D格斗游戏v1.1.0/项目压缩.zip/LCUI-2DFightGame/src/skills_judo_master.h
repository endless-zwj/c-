﻿#ifndef __JUDO_MASTER_SKILL__
#define __JUDO_MASTER_SKILL__

#define SKILLNAME_JUDO			"judo"
#define SKILLNAME_BACK_JUDO		"back judo"
#define SKILLPRIORITY_JUDO		SKILLPRIORITY_MACH_A_ATTACK
#define SKILLPRIORITY_BACK_JUDO		SKILLPRIORITY_MACH_A_ATTACK

/** 注册柔道家特有的技能 */
void JudoMasterSkill_Register(void);

#endif
