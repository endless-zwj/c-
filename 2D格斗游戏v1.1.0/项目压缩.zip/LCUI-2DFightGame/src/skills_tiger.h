﻿#ifndef __TIGER_SKILL_H__
#define __TIGER_SKILL_H__

#define ATK_SPIN_DRILL			"spin drill attack"
#define SKILLNAME_SPIN_DRILL		"spin drill"
#define SKILLPRIORITY_SPIN_DRILL	0

/** 注册老虎特有的技能 */
void TigerSkill_Register(void);

#endif
