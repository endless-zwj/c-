﻿#ifndef __GAME_WINDOW_JOINUS_H__
#define __GAME_WINDOW_JOINUS_H__

void GameWindow_InitJoinUsWindow(void);

void GameWindow_ShowJoinUsWindow(void);

void GameWindow_HideJoinUsWindow(void);

void GameWindow_DestroyJoinUsWindow(void);

#endif
