﻿
extern void Game_InitMainUI(void);
extern void Game_ShowMainUI(void);
extern void Game_HideMainUI(void);

extern LCUI_Widget* Game_GetMainUI(void);
