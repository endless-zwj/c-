﻿#ifndef __GAME_WINDOW_USAGE_H__
#define __GAME_WINDOW_USAGE_H__

void GameWindow_InitUsageWindow(void);

void GameWindow_ShowUsageWindow(void);

void GameWindow_HideUsageWindow(void);

void GameWindow_DestroyUsageWindow(void);

#endif
