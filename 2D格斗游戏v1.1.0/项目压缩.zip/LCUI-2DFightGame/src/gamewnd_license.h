#ifndef __GAME_WINDOW_LICENSE_H__
#define __GAME_WINDOW_LICENSE_H__

void GameWindow_InitLicenseWindow(void);

void GameWindow_ShowLicenseWindow(void);

void GameWindow_HideLicenseWindow(void);

void GameWindow_DestroyLicenseWindow(void);

#endif
